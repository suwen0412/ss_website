# Gamry .DTA Exporter UI (CV / EIS / General)

This UI is **general** and works well for EIS files that do not have "cycle numbers".

## Key idea
`parse_gamry_dta()` typically returns a list of DataFrames called "curves".
For CV you might think of these as cycles; for EIS they may be:
- the main dataset
- repeated runs
- auxiliary blocks

The UI lets you export:
- **RAW export** (recommended): ALL columns as-is, one sheet per curve
- **VIT export** (optional): map V/I/T-like columns and export standardized sheets

## Install
```bash
pip install -r requirements.txt
```

## Run
```bash
python app.py
```
