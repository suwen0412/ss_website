import numpy as np
import pandas as pd
from .dta_parser import parse_gamry_dta

def _guess_time_col(df):
    candidates = ["T","Time","Time/s","Time_Sec","s","Sec","Seconds","time","TIME"]
    for c in candidates:
        if c in df.columns:
            return c
    for c in df.columns:
        lc = str(c).lower()
        if "time" in lc or lc == "t" or lc.startswith("t(") or lc.endswith("(s)"):
            return c
    return None

def load_IVT_gamry(dta_path: str, k: int = 1, potential_col='Vf', current_col='Im',
                   time_col=None, sort_by_time=True):
    header, curves = parse_gamry_dta(dta_path)
    if k < 1 or k > len(curves):
        raise IndexError(f"Requested cycle k={k}, but file has {len(curves)} curve(s).")
    df = curves[k-1].copy()
    missing = [c for c in (potential_col, current_col) if c not in df.columns]
    if missing:
        raise KeyError(f"Missing column(s) {missing} in curve {k}. Available: {list(df.columns)}")
    tcol = time_col if (time_col and time_col in df.columns) else _guess_time_col(df)
    if tcol is None:
        df['__T__synth'] = np.arange(len(df), dtype=float)
        tcol = '__T__synth'
    for c in (potential_col, current_col, tcol):
        df[c] = pd.to_numeric(df[c], errors='coerce')
    if sort_by_time:
        df = df.sort_values(tcol, kind='mergesort').reset_index(drop=True)
    V = df[potential_col].to_numpy(float)
    I = df[current_col].to_numpy(float)
    T = df[tcol].to_numpy(float)
    return V, I, T

def load_IV_gamry(dta_path: str, k: int = 1, potential_col='Vf', current_col='Im',
                  sort_by_time=True):
    V, I, _T = load_IVT_gamry(dta_path, k=k, potential_col=potential_col,
                              current_col=current_col, time_col=None,
                              sort_by_time=sort_by_time)
    return V, I

def dta_to_df_gamry(dta_path: str, label: str, k: int = 1,
                    potential_col='Vf', current_col='Im', time_col=None):
    V, I, T = load_IVT_gamry(dta_path, k=k, potential_col=potential_col,
                             current_col=current_col, time_col=time_col, sort_by_time=True)
    R = np.divide(V, I, out=np.full_like(V, np.nan, dtype=float), where=I != 0)
    import pandas as pd
    out = pd.DataFrame({
        'label': label,
        'cycle': k,
        'idx': np.arange(len(V), dtype=int),
        'T': T.astype(float),
        'V': V.astype(float),
        'I': I.astype(float),
        'R': R.astype(float),
    })
    return out

def load_np_from_gamry(np1_path: str, np2_path: str, k: int = 1):
    return (
        dta_to_df_gamry(np1_path, label='NP1', k=k),
        dta_to_df_gamry(np2_path, label='NP2', k=k),
    )