import re
import numpy as np
import pandas as pd
from pathlib import Path

_float = lambda s: float(s.replace('D','E'))  # handle Fortran 'D' exponents

def _safe_float(tok):
    try:
        return _float(tok)
    except Exception:
        return np.nan

def _looks_curve_line(line):
    # e.g., "CURVE1\tTABLE" or "CURVE2  TABLE"
    return bool(re.match(r'^\s*CURVE\d+\s+TABLE', line))

def parse_gamry_dta(dta_path: str):
    """Parse a Gamry .DTA file (text format).
    Returns:
        header: dict of key -> parsed value(s)
        curves: list[pd.DataFrame], one per CURVE (cycle)
    """
    p = Path(dta_path)
    with p.open('r', encoding='latin-1', errors='ignore') as f:
        lines = f.read().splitlines()

    header = {}
    curves = []
    i = 0
    n = len(lines)

    # header
    while i < n and not _looks_curve_line(lines[i]):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        parts = [x for x in re.split(r'\t+', line) if x != '']
        if len(parts) >= 3:
            key, typ, *rest = parts
            vals = []
            for tok in rest:
                if re.match(r'^[A-Za-z&].*', tok) and not re.match(r'^[+-]?\d', tok):
                    break
                vals.append(tok)
            nums = [_safe_float(v) for v in vals if v]
            if len(nums) == 0:
                header[key] = " ".join(rest).strip()
            elif len(nums) == 1:
                header[key] = nums[0]
            else:
                header[key] = nums
        i += 1

    # curves
    while i < n:
        while i < n and not _looks_curve_line(lines[i]):
            i += 1
        if i >= n:
            break

        # "CURVEk    TABLE"
        i += 1
        if i+1 >= n:
            break

        col_line = lines[i].strip()
        unit_line = lines[i+1].strip()
        i += 2

        cols = [c for c in re.split(r'\s+', col_line) if c]
        data = []
        while i < n and lines[i].strip() and not _looks_curve_line(lines[i]):
            row = [tok for tok in re.split(r'\s+', lines[i].strip()) if tok]
            if len(row) < len(cols):
                row += [''] * (len(cols) - len(row))
            elif len(row) > len(cols):
                row = row[:len(cols)]
            data.append(row)
            i += 1

        df = pd.DataFrame(data, columns=cols)
        for c in df.columns:
            df[c] = pd.to_numeric(df[c].str.replace(',', '', regex=False), errors='coerce')
        df['cycle'] = len(curves) + 1
        curves.append(df)

        while i < n and not _looks_curve_line(lines[i]) and not lines[i].strip():
            i += 1

    return header, curves