import os
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox

import pandas as pd

from gamry_utils.dta_parser import parse_gamry_dta


def safe_sheet_name(name: str) -> str:
    bad = '[]:*?/\\'
    for ch in bad:
        name = name.replace(ch, "_")
    name = name.strip() or "Sheet"
    return name[:31]


def base_name(path: str) -> str:
    b = os.path.basename(path)
    return os.path.splitext(b)[0]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gamry .DTA Exporter (CV / EIS / General)")
        self.geometry("900x560")
        self.minsize(860, 520)

        self.dta_path = tk.StringVar(value="")
        self.out_path = tk.StringVar(value="")

        self.header = None
        self.curves = []
        self.columns = []

        self.curve_choice = tk.StringVar(value="All curves")
        self.x_col = tk.StringVar(value="")
        self.y_col = tk.StringVar(value="")
        self.t_col = tk.StringVar(value="")

        self._build()

    def _build(self):
        pad = {"padx": 12, "pady": 8}

        tk.Label(
            self,
            text="Gamry .DTA → Excel (works for CV, EIS, and most Gamry exports)",
            font=("Arial", 15, "bold"),
        ).pack(anchor="w", **pad)

        top = tk.Frame(self)
        top.pack(fill="x", **pad)

        r1 = tk.Frame(top); r1.pack(fill="x")
        tk.Label(r1, text="Input .DTA:", width=12, anchor="w").pack(side="left")
        tk.Entry(r1, textvariable=self.dta_path).pack(side="left", fill="x", expand=True, padx=(0, 8))
        tk.Button(r1, text="Browse…", command=self.browse_dta).pack(side="left")

        r2 = tk.Frame(top); r2.pack(fill="x", pady=(8, 0))
        tk.Label(r2, text="Output .xlsx:", width=12, anchor="w").pack(side="left")
        tk.Entry(r2, textvariable=self.out_path).pack(side="left", fill="x", expand=True, padx=(0, 8))
        tk.Button(r2, text="Save as…", command=self.browse_out).pack(side="left")

        mid = tk.Frame(self)
        mid.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        left = tk.LabelFrame(mid, text="Export options", width=360)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)

        right = tk.LabelFrame(mid, text="Preview")
        right.pack(side="left", fill="both", expand=True)

        tk.Label(left, text="Load the DTA, then export RAW (recommended) or mapped VIT.", fg="#333",
                 wraplength=330).pack(anchor="w", padx=10, pady=(10, 8))
        tk.Button(left, text="Load / Refresh file", command=self.load_file).pack(anchor="w", padx=10, pady=(0, 10))

        frm_curve = tk.Frame(left); frm_curve.pack(fill="x", padx=10, pady=(0, 8))
        tk.Label(frm_curve, text="Curve:", width=10, anchor="w").pack(side="left")
        self.curve_menu = tk.OptionMenu(frm_curve, self.curve_choice, "All curves")
        self.curve_menu.config(width=20)
        self.curve_menu.pack(side="left", fill="x", expand=True)

        tk.Label(left, text="RAW export (best for EIS):", font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(10, 2))
        tk.Label(left, text="Exports ALL columns as-is. One sheet per curve.", wraplength=330, fg="#444").pack(anchor="w", padx=10, pady=(0, 8))
        tk.Button(left, text="Export RAW (all columns)", command=self.export_raw, bg="#1f6feb", fg="white").pack(fill="x", padx=10, pady=(0, 10))

        tk.Label(left, text="Optional VIT export (map columns):", font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(12, 2))
        tk.Label(left, text="Pick V/I/T-like columns and export standardized VIT sheets.", wraplength=330, fg="#444").pack(anchor="w", padx=10, pady=(0, 6))

        frm_map1 = tk.Frame(left); frm_map1.pack(fill="x", padx=10, pady=3)
        tk.Label(frm_map1, text="V (x):", width=10, anchor="w").pack(side="left")
        self.om_x = tk.OptionMenu(frm_map1, self.x_col, "")
        self.om_x.config(width=18); self.om_x.pack(side="left", fill="x", expand=True)

        frm_map2 = tk.Frame(left); frm_map2.pack(fill="x", padx=10, pady=3)
        tk.Label(frm_map2, text="I (y):", width=10, anchor="w").pack(side="left")
        self.om_y = tk.OptionMenu(frm_map2, self.y_col, "")
        self.om_y.config(width=18); self.om_y.pack(side="left", fill="x", expand=True)

        frm_map3 = tk.Frame(left); frm_map3.pack(fill="x", padx=10, pady=3)
        tk.Label(frm_map3, text="T (time):", width=10, anchor="w").pack(side="left")
        self.om_t = tk.OptionMenu(frm_map3, self.t_col, "")
        self.om_t.config(width=18); self.om_t.pack(side="left", fill="x", expand=True)

        tk.Button(left, text="Export VIT (mapped columns)", command=self.export_vit).pack(fill="x", padx=10, pady=(8, 10))

        self.status = tk.Label(self, text="Ready.", anchor="w", fg="#333")
        self.status.pack(fill="x", padx=12, pady=(0, 10))

        self.preview = tk.Text(right, wrap="word")
        self.preview.pack(fill="both", expand=True, padx=10, pady=10)
        self.preview.insert("end", "Load a .DTA file to preview header, curves, and columns.\n")

    def browse_dta(self):
        path = filedialog.askopenfilename(
            title="Select Gamry DTA file",
            filetypes=[("Gamry DTA", "*.DTA *.dta"), ("All files", "*.*")]
        )
        if not path:
            return
        self.dta_path.set(path)
        if not self.out_path.get().strip():
            self.out_path.set(os.path.join(os.path.dirname(path), base_name(path) + ".xlsx"))
        self.status.config(text="Selected input file. Click 'Load / Refresh file'.")

    def browse_out(self):
        path = filedialog.asksaveasfilename(
            title="Save Excel file as",
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")]
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        self.out_path.set(path)
        self.status.config(text="Selected output file.")

    def _set_option_menu(self, opt_menu: tk.OptionMenu, var: tk.StringVar, choices):
        menu = opt_menu["menu"]
        menu.delete(0, "end")
        menu.add_command(label="", command=lambda: var.set(""))
        for ch in choices:
            menu.add_command(label=str(ch), command=lambda v=ch: var.set(str(v)))
        if var.get() not in [str(c) for c in choices]:
            var.set("")

    def load_file(self):
        self.preview.delete("1.0", "end")
        p = self.dta_path.get().strip()
        if not p:
            messagebox.showwarning("Missing input", "Please choose a .DTA file first.")
            return
        try:
            header, curves = parse_gamry_dta(p)
            self.header, self.curves = header, curves

            n = len(curves)
            menu = self.curve_menu["menu"]
            menu.delete(0, "end")
            self.curve_choice.set("All curves")
            menu.add_command(label="All curves", command=lambda: self.curve_choice.set("All curves"))
            for i in range(1, n + 1):
                lab = f"Curve {i}"
                menu.add_command(label=lab, command=lambda v=lab: self.curve_choice.set(v))

            # union columns
            col_union, seen = [], set()
            for cdf in curves:
                for c in list(cdf.columns):
                    if c not in seen:
                        seen.add(c); col_union.append(c)
            self.columns = col_union

            self._set_option_menu(self.om_x, self.x_col, self.columns)
            self._set_option_menu(self.om_y, self.y_col, self.columns)
            self._set_option_menu(self.om_t, self.t_col, self.columns)

            def pick_first(names):
                for nm in names:
                    for c in self.columns:
                        if str(c).lower() == nm.lower():
                            return str(c)
                for nm in names:
                    for c in self.columns:
                        if nm.lower() in str(c).lower():
                            return str(c)
                return ""

            self.x_col.set(pick_first(["Vf","V","Potential","Ewe","E"]))
            self.y_col.set(pick_first(["Im","I","Current"]))
            self.t_col.set(pick_first(["Time","T","Time/s","Seconds","Sec"]))

            msg = []
            msg.append(f"File: {p}")
            msg.append(f"Detected curves: {n}")
            if header:
                keys = list(header.keys())
                msg.append(f"Header keys (first 25): {', '.join(map(str, keys[:25]))}")
            msg.append("")
            msg.append("Columns (union across curves):")
            msg.append("  " + ", ".join(map(str, self.columns)))
            msg.append("")
            if n:
                msg.append("Curve sizes:")
                for i, cdf in enumerate(curves[:10], start=1):
                    msg.append(f"  Curve {i}: {len(cdf)} rows, {len(cdf.columns)} cols")
                if n > 10:
                    msg.append(f"  ... ({n-10} more)")
            self.preview.insert("end", "\n".join(msg))
            self.status.config(text="Loaded file. Export RAW (all columns) for EIS; use VIT mapping for CV.")
        except Exception as e:
            self.preview.insert("end", "Load failed:\n" + repr(e) + "\n\n" + traceback.format_exc())
            self.status.config(text="Load failed.")

    def _selected_indices(self):
        if not self.curves:
            raise ValueError("No curves loaded. Click 'Load / Refresh file' first.")
        choice = self.curve_choice.get()
        if choice == "All curves":
            return list(range(len(self.curves)))
        if choice.startswith("Curve "):
            return [int(choice.split()[-1]) - 1]
        return list(range(len(self.curves)))

    def export_raw(self):
        p = self.dta_path.get().strip()
        outp = self.out_path.get().strip()
        if not p:
            messagebox.showwarning("Missing input", "Please choose a .DTA file first.")
            return
        if not outp:
            messagebox.showwarning("Missing output", "Please choose an output .xlsx path.")
            return
        try:
            if not self.curves:
                self.load_file()
            idxs = self._selected_indices()

            os.makedirs(os.path.dirname(os.path.abspath(outp)) or ".", exist_ok=True)
            with pd.ExcelWriter(outp, engine="openpyxl") as writer:
                meta = {
                    "input_file": p,
                    "export_mode": "RAW (all columns)",
                    "selected": self.curve_choice.get(),
                    "n_curves_detected": len(self.curves),
                    "header_keys": ", ".join(map(str, list(self.header.keys())[:80])) if self.header else "",
                    "columns_union": ", ".join(map(str, self.columns)) if self.columns else "",
                }
                pd.DataFrame([meta]).to_excel(writer, sheet_name="_meta", index=False)

                for idx in idxs:
                    df = self.curves[idx].copy()
                    sheet = safe_sheet_name(f"{base_name(p)}_c{idx+1}")
                    df.to_excel(writer, sheet_name=sheet, index=False)

            self.status.config(text=f"Exported RAW: {outp}")
            messagebox.showinfo("Done", f"RAW export successful:\n{outp}")
        except Exception as e:
            messagebox.showerror("Export failed", repr(e) + "\n\n" + traceback.format_exc())
            self.status.config(text="Export failed.")

    def export_vit(self):
        p = self.dta_path.get().strip()
        outp = self.out_path.get().strip()
        if not p:
            messagebox.showwarning("Missing input", "Please choose a .DTA file first.")
            return
        if not outp:
            messagebox.showwarning("Missing output", "Please choose an output .xlsx path.")
            return
        try:
            if not self.curves:
                self.load_file()
            idxs = self._selected_indices()

            x = self.x_col.get().strip()
            y = self.y_col.get().strip()
            t = self.t_col.get().strip()

            if not x or not y:
                messagebox.showwarning("Missing mapping", "Select at least V(x) and I(y) columns.")
                return

            os.makedirs(os.path.dirname(os.path.abspath(outp)) or ".", exist_ok=True)
            with pd.ExcelWriter(outp, engine="openpyxl") as writer:
                meta = {
                    "input_file": p,
                    "export_mode": "VIT (mapped columns)",
                    "selected": self.curve_choice.get(),
                    "x_col": x,
                    "y_col": y,
                    "t_col": t or "(none; synth idx)",
                    "n_curves_detected": len(self.curves),
                }
                pd.DataFrame([meta]).to_excel(writer, sheet_name="_meta", index=False)

                for idx in idxs:
                    raw = self.curves[idx].copy()
                    missing = [c for c in [x, y] if c not in raw.columns]
                    if missing:
                        raise KeyError(f"Curve {idx+1} missing columns: {missing}. Available: {list(raw.columns)}")

                    V = pd.to_numeric(raw[x], errors="coerce").astype(float)
                    I = pd.to_numeric(raw[y], errors="coerce").astype(float)
                    if t and t in raw.columns:
                        T = pd.to_numeric(raw[t], errors="coerce").astype(float)
                    else:
                        T = pd.Series(range(len(raw)), dtype=float)

                    R = V.divide(I).where(I != 0)
                    df = pd.DataFrame({"curve": idx+1, "idx": range(len(raw)), "T": T, "V": V, "I": I, "R": R})

                    sheet = safe_sheet_name(f"VIT_c{idx+1}")
                    df.to_excel(writer, sheet_name=sheet, index=False)

            self.status.config(text=f"Exported VIT: {outp}")
            messagebox.showinfo("Done", f"VIT export successful:\n{outp}")
        except Exception as e:
            messagebox.showerror("Export failed", repr(e) + "\n\n" + traceback.format_exc())
            self.status.config(text="Export failed.")


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
